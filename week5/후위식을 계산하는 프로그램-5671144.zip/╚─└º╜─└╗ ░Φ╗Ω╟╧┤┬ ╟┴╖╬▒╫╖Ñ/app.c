﻿#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define MAX_STACK_SIZE 10

typedef int element;

typedef struct
{
	element* data;
	int capacity;
	int top;
} StackType;

StackType* create(int size) {
	StackType* sp;
	sp = malloc(sizeof(StackType));
	sp->capacity = size;
	sp->data = malloc(size * sizeof(element));
	sp->top = -1;
	return sp;
}

int isFull(StackType* sp) {
	return (sp->top == (sp->capacity - 1));
}

int push(StackType* sp, element itme) {
	if (isFull(sp)) {
		sp->capacity *= 2;
		sp->data = (element*)realloc(sp->data, sp->capacity * sizeof(element));
	}
	sp->top++;
	sp->data[sp->top] = itme;
}

int isEmpty(StackType* sp) {
	return (sp->top == -1);
}

element pop(StackType* sp) {
	if (isEmpty(sp))
	{
		fprintf(stderr, "stack 공백 에러 \n");
		return -1;
	}
	element result = sp->data[sp->top];
	sp->top--;
	return result;
}

int isCurrentInput(char string)
{

	if (string == '+' || string == '-' || string == '*' || string == '/')
	{
		return 1;
	}

	if (isdigit(string))
	{
		return 1;
	};

	return 0; // 위의 조건에 포함되지 않으면 error처리
}


int main() {
	srand(time(NULL));

	StackType* stack = create(MAX_STACK_SIZE);
	char inputTerm[100];

	int op1, op2, value = 0;
	char ch;

	printf("후위식을 입력해주세요. 숫자 나 연산자를 입력해주세요. 단 괄호와 문자는 불가능합니다. \n");
	printf("Current Case => [0 1 +] [0 1 + ] [ 0 1 + ] [01+]  \n");
	printf("Error Case => [ddf +] [ (1+2) ] \n");
	printf("Postfix expression: ");
	scanf("%[^\n]s", inputTerm);     // ( 공백 포함 문자열 입력 )

	for (int i = 0; i < strlen(inputTerm); i++) {
		if (inputTerm[i] != ' ') {
			ch = inputTerm[i];
			if (isCurrentInput(ch) != 1) {
				fprintf(stderr, "Error: Invalid character\n");
				exit(1);
			}
		}
	}

	for (int i = 0; i < strlen(inputTerm); i++) {
		if (inputTerm[i] != ' ') {
			ch = inputTerm[i];

			if (ch != '+' && ch != '-' && ch != '*' && ch != '/')
			{
				value = ch - '0';
				push(stack, value);
			}
			else
			{
				op2 = pop(stack);
				op1 = pop(stack);
				switch (ch)
				{
				case '+':
					push(stack, op1 + op2);
					break;
				case '-':
					push(stack, op1 - op2);
					break;
				case '*':
					push(stack, op1 * op2);
					break;
				case '/':
					push(stack, op1 / op2);
					break;
				}
			}

		}
	}

	printf("Result: %d\n", stack->data[0]);
	free(stack->data);
	free(stack);
	return 0;
}