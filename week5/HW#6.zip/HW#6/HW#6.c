﻿#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>

#define MAX_STACK_SIZE 100

typedef char* element;

// 스택 /////////////////////////
typedef struct
{
	element* data;
	int capacity;
	int top;
} StackType;

StackType* create(int size)
{
	StackType* sp; // stack pointer
	sp = malloc(sizeof(StackType));
	sp->capacity = size;
	sp->data = malloc(size * sizeof(element));
	sp->top = -1;
	return sp;
}

int isFull(StackType* sp)
{
	return (sp->top == (sp->capacity - 1));
}

void push(StackType* sp, element item)
{
	if (isFull(sp))
	{
		sp->capacity *= 2; // 배열의 길이
		sp->data = (element*)realloc(sp->data, sp->capacity * sizeof(element));
	}
	sp->top++;
	sp->data[sp->top] = item;
}

int isEmpty(StackType* sp)
{
	return (sp->top == -1);
}

element pop(StackType* sp)
{
	if (isEmpty(sp))
	{
		fprintf(stderr, "stack 공백 에러 \n");
		return -1;
	}
	element result = sp->data[sp->top];
	sp->top--;
	return result;
}

element peek(StackType* sp)
{
	return sp->data[sp->top];
}

/////////////////////////////////

int prec(char op)
{
	switch (op)
	{
	case ('('):
	case (')'):
		return 0;
		break;
	case '+':
	case '-':
		return 1;
	case ('*'):
	case ('/'):
		return 2;
	}
	return -1;
}

void errorCheck(char exp[]) {
	// error check
	char prev = ' ';
	int operCount = 0; // 괄호 갯수 확인용 카운터입니다.
	for (int ei = 0; ei < strlen(exp); ei++)
	{
		char ch = exp[ei];
		if (!isspace(ch)) // 공백인지 확인.
		{
			if (isdigit(ch)) {
				prev = '1';
				continue;
			}
			if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '(' || ch == ')') {
				if (ch == '(') {
					operCount++;
					prev = '(';
					continue;
				}
				if (ch == ')') {
					operCount++;
					prev = ')';
					continue;
				}
				// 중위식이기에 오퍼레이터의 이전에는 괄호나 숫자만이 존재할수 있습니다.
				if (prev != ')' && prev != '(' && !isdigit(prev)) {
					fprintf(stderr, "Error : Invalid expression.");
					exit(1);
				}
				else {
					prev = ' ';
				}
			}
			else {
				fprintf(stderr, "Error : Invalid character");
				exit(1);
			}
		}
	}
	if (operCount % 2 != 0) {
		fprintf(stderr, "Error : Mismatched parentheses");
		exit(1);
	}
	// error check
}

// 중위식 -> 후위식
char* infixToPostfix(char exp[])
{
	StackType* stack = create(MAX_STACK_SIZE);
	char topOp;
	char num[100] = "";
	int numIndex = 0;

	errorCheck(exp);

	int idx = 0; // 결과값을 저장하기 위해서 idx를 사용합니다.
	char result[300] = "";

	for (int i = 0; i < strlen(exp); i++)
	{
		char ch = exp[i];
		if (!isspace(ch)) // 공백인지 확인.
		{
			if (isdigit(ch)) { // 현재 문자가 숫자일떄 
				num[numIndex++] = ch;
				continue;
			}
			else { // 현재 들어온 문자가 문자일떄.


				if (numIndex > 0) {
					for (int numI = 0; numI < numIndex; numI++) {
						result[idx++] = num[numI];
					}
					result[idx++] = ' ';
					memset(num, 0, 100); // 문자 를 저장하던 배열을 초기화 합니다.
					numIndex = 0; // 문자 를 저장하던 배열의 index를 초기화 합니다.
				}
			}
			switch (ch)
			{
			case '+':
			case '-':
			case '*':
			case '/':
				while (!isEmpty(stack) && (prec(ch) <= prec(peek(stack))))
				{
					result[idx++] = pop(stack);
					result[idx++] = ' ';
				}
				push(stack, ch);
				break;
			case '(':
				push(stack, ch);
				break;
			case ')':
				topOp = pop(stack);
				while (topOp != '(')
				{
					result[idx++] = topOp;
					result[idx++] = ' ';
					topOp = pop(stack);
				}
				break;
			default:
				break;
			}


		}
	}
	if (numIndex > 0) {
		for (int numI = 0; numI < numIndex; numI++) {
			result[idx++] = num[numI];
		}
		result[idx++] = ' ';

	}
	while (!isEmpty(stack)) // 스택에 남은 연산자 출력을 합니다.
	{
		result[idx++] = pop(stack);
		result[idx++] = ' ';
		break;
	}
	return result;
}

int main()
{
	StackType* stack = create(MAX_STACK_SIZE);
	int op1, op2, value = 0;
	char ch;
	char inputTerm[100];
	char currntInput[100]; // 후위식 입니다.
	char num[100] = "";
	int numIndex = 0;

	printf("Enter an infix expression: ");
	scanf("%[^\n]s", inputTerm);

	strcpy(currntInput, infixToPostfix(inputTerm));
	printf("Postfix expression: %s\n", currntInput);
	/// 계산 ///////////////////////////////
	// currntInput => 222 110 1 + / 3 *

	for (int i = 0; i < strlen(currntInput); i++) {
		if (currntInput[i] != ' ') {
			ch = currntInput[i];
			if (isdigit(ch))
			{
				num[numIndex++] = ch;
			}
			else {

				op2 = pop(stack);
				op1 = pop(stack);
				switch (ch)
				{
				case '+':
					push(stack, op1 + op2);
					break;
				case '-':
					push(stack, op1 - op2);
					break;
				case '*':
					push(stack, op1 * op2);
					break;
				case '/':
					push(stack, op1 / op2);
					break;
				}
			}
		}
		else {
			if (strlen(num) != 0) {
				value = atoi(num); // atoi -> 문자열에 있는값을 정수로 바꿔줍니다!
				push(stack, value);

				memset(num, 0, 100); // 문자 를 저장하던 배열을 초기화 합니다.
				numIndex = 0;
			}

		}
	}
	printf("Result: %d\n", stack->data[0]);

	free(stack->data);
	free(stack);
	return 0;
}