﻿#include <stdio.h>
#include <stdlib.h>

#define MAX_QUEUE_SIZE 5

typedef int element;
typedef struct
{
    int front;
    int rear;
    element data[MAX_QUEUE_SIZE];
} QueueType;

void init(QueueType* queue)
{
    queue->front = 0;
    queue->rear = 0;
}

int isEmpty(QueueType* queue)
{
    return queue->front == queue->rear ? 1 : 0;
}

int isFull(QueueType* queue)
{
    return (queue->rear + 1) % MAX_QUEUE_SIZE == queue->front ? 1 : 0;
}

// 큐에 값이 정상적으로 들어갓다면 1 아니면 0
void enqueue(QueueType* queue, element item)
{
    // 원형이기에 (queue->rear + 1) % MAX_QUEUE_SIZE
    queue->rear = (queue->rear + 1) % MAX_QUEUE_SIZE;
    queue->data[queue->rear] = item;
}

element dequeue(QueueType* queue)
{
    if (isEmpty(queue))
    {
        printf("Queue is empty\n");
        return -1;
    }
    queue->front = (queue->front + 1) % MAX_QUEUE_SIZE;
    return queue->data[queue->front];
}

void printQueue(QueueType* queue)
{
    printf("Queue(front = %d rear = %d): ", queue->front, queue->rear);
    if (!isEmpty(queue))
    {
        int i = queue->front;
        do
        {
            i = (i + 1) % MAX_QUEUE_SIZE;
            printf("%d ", queue->data[i]);
            if (i == queue->rear)
                break;
        } while (i != queue->front);
    }
    printf("\n");
}

int main()
{
    QueueType queue;
    int menu;
    int item;
    init(&queue);
    // printf("%d\n", isEmpty(&queue));
    // enqueue(&queue, 1);
    // printf("%d\n", isEmpty(&queue));
    while (1)
    {
        printf("\n");
        printf("==== Menu ====\n");
        printf("1. Input data and Enqueue\n");
        printf("2. Dequeue and Print Data\n");
        printf("3. Print Queue\n");
        printf("4. Exit\n");
        printf("Select number: ");
        scanf_s("%d", &menu);
        printf("\n");
        switch (menu)
        {
        case 1:
            if (isFull(&queue))
            {
                printf("Queue is Full\n");
                break;
            }
            printf("Input the data : ");
            scanf_s("%d", &item);
            enqueue(&queue, item);
            printf("Enqueue: %d\n", item);
            break;
        case 2:
            item = dequeue(&queue);
            if (item != -1)
            {
                printf("Dequeue: %d\n", item);
            }
            break;
        case 3:
            printQueue(&queue);
            break;
        case 4:
            printf("Exit the program.\n");
            exit(1);
            break;
        default:
            break;
        }
    }
}
