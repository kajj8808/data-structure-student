﻿#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

#define MAX_STACK_SIZE 100

// 스택 구조체 정의
typedef struct {
    char data[MAX_STACK_SIZE];
    int top;
} stacktype;

// 스택 초기화 함수
void init(stacktype* s) {
    s->top = -1;
}

// 스택이 비어있는지 검사하는 함수
int is_empty(stacktype* s) {
    return (s->top == -1);
}

// 스택이 가득 차 있는지 검사하는 함수
int is_full(stacktype* s) {
    return (s->top == MAX_STACK_SIZE - 1);
}

// 스택에 데이터를 추가하는 함수
void push(stacktype* s, char c) {
    if (is_full(s)) {
        printf("스택이 가득 찼습니다.");
        return;
    }
    s->data[++(s->top)] = c;
}

// 스택에서 데이터를 삭제하고 반환하는 함수
char pop(stacktype* s) {
    if (is_empty(s)) {
        printf("스택이 비어있습니다.");
        return '\0';
    }
    return s->data[(s->top)--];
}

// 회문 검사 함수
int checkPalindrome(char input_string[]) {
    stacktype s;
    int i, len;
    char c;

    // 문자열의 길이를 확인합니다.
    len = strlen(input_string);

    // 스택 초기화
    init(&s);

    // 문자열을 스택에 추가
    for (i = 0; i < len; i++) {
        // 소문자로 변환해주는 함수입니다. 입력값을 소문자로 변환시켜줍니다.
        c = tolower(input_string[i]);
        // 알파벳인지 확인하는 함수입니다. 확인후 맞다면 push 를해줍니다.
        if (isalpha(c)) {
            push(&s, c);
        }
    }

    // 스택에서 데이터를 꺼내면서 입력 문자열과 비교
    for (i = 0; i < len; i++) {
        c = tolower(input_string[i]);
        if (isalpha(c)) {
            // stack 에 있는 값을 꺼내보고 회문인지 확인합니다.
            if (pop(&s) != c) {
                return 0; // 회문이 아니라면 0을 return 합니다.
            }
        }
    }

    return 1;
}

int main() {
    char input_string[100]; // 문자열을 입력받습니다.
    char yesNo[10]; // 프로그램을 다시시작 할지를 묻는 String 을 저장하기위해 사용합니다.
    while (true)
    {
        printf("문자열을 입력하시오: ");
        fgets(input_string, sizeof(input_string), stdin); // fgets 사용해 공백까지 입력받습니다.
        if (checkPalindrome(input_string) == 1) {
            printf("회문입니다.\n");
        }
        else {
            printf("회문이 아닙니다.\n");
        }

        printf("\n");
        printf("계속 입력하시겠습니까?(Yes/No): ");
        scanf_s("%s", yesNo, (int)sizeof(yesNo));
        getchar(); // 개행 문자 제거 값을 다시받기 위해 사용합니다.
        printf("\n");

        if (strcmp(yesNo, "Yes") == 0) {
            continue;
        }
        else if (strcmp(yesNo, "No") == 0)
        {
            break;
        }
        else {
            printf("잘못된 입력입니다. 프로그램을 종료합니다.\n");
            break;
        }
    }
}