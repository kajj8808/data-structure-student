﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct Node {
	char* data;
	struct Node* prev;
	struct Node* next;
} Node;

Node* currentNode = NULL;

// 현재 아이템 다음에 데이터 추가. ( i )
Node* insert(Node* prevNode, char* data) {
	Node* newNode = (Node*)malloc(sizeof(Node));
	newNode->data = malloc(strlen(data) + 1); // 문자열 마지막에 \0 이 있기에 +1 을 해줍니다.
	strcpy(newNode->data, data);

	// 리스트 중간에 값을 넣습니다.
	newNode->prev = prevNode; // new node 의 이전 node 를 현재 연결하고자하는 노드로 지정합니다.
	newNode->next = prevNode->next;

	prevNode->next->prev = newNode;
	prevNode->next = newNode;

	return newNode;
}

// 삭제함수입니다.
void delete(Node* head, Node* removed) {
	if (removed == head) return;
	removed->prev->next = removed->next;
	removed->next->prev = removed->prev;
	free(removed);
}

// init 함수입니다. head를 초기화합니다.
void init(Node* head) {
	head->prev = head;
	head->next = head;
}

// list 를 출력하는 함수입니다. current Node 즉 선택된 node일 경우 [0]을 붙힙니다.
void printList(Node* head) {
	Node* p;
	for (p = head->next; p != head; p = p->next) {
		printf("%s%s\n", p->data, p == currentNode ? " [O]" : "");
	}
}



int main() {
	Node* head = (Node*)malloc(sizeof(Node));
	char command;
	char data[100];
	init(head);

	while (true)
	{
		printf("==== Menu ====\n");
		printf("n) next fruit\n");
		printf("p) previous fruit\n");
		printf("d) delete the current fruit\n");
		printf("i) insert fruit after current fruit\n");
		printf("o) output the fruit list ( current fruit [0] )\n");
		printf("e) exit the program\n");
		printf("==============\n");
		printf("Select a menu : ");
		scanf(" %c", &command); // 공백을 추가하여 개행문자를 삭제합니다!

		switch (command)
		{
		case 'n':
			if (currentNode) {
				currentNode = currentNode->next;
				break;
			}
			break;
		case 'p':
			if (currentNode) {
				currentNode = currentNode->prev;
				break;
			}
			break;
		case 'd':
			currentNode = currentNode->next;
			delete(head, currentNode->prev);
			break;
		case 'i':
			printf("Enter the name of the fruit to add : ");
			scanf("%s", data);
			if (!currentNode) { // 처음 과일을 추가하면 해당 과일이 선택된 상태로 과일 리스트를 관리합니다.
				currentNode = insert(head, data);
				break;
			}
			insert(currentNode, data);
			break;
		case 'o':
			printList(head);
			break;
		case 'e':
			exit(0);
			break;
		default:
			printf("Invalid menu. \n");
			break;
		}
		printf("\n");
	}


}
