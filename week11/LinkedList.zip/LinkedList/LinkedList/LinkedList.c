﻿#include <stdio.h>
#include <stdlib.h>

typedef int element;
typedef struct ListNode
{
	element data;
	struct ListNode* link;
} ListNode;

ListNode* insertFirst(ListNode* head, int item)
{
	ListNode* node = (ListNode*)malloc(sizeof(ListNode));
	node->data = item;
	node->link = head;
	head = node;
	return head;
}

ListNode* deleteFirst(ListNode* head)
{
	ListNode* removed;
	if (head == NULL)
	{
		return NULL;
	}
	removed = head;
	head = removed->link;
	free(removed);
	return head;
}

ListNode* insert(ListNode* head, ListNode* pre, element item)
{
	ListNode* node = (ListNode*)malloc(sizeof(ListNode));

	node->data = item;
	node->link = pre->link;
	pre->link = node;
	return head;
}

ListNode* delete(ListNode* head, ListNode* pre)
{
	ListNode* removed;
	removed = pre->link;
	pre->link = removed->link;
	free(removed);
	return head;
}

void printList(ListNode* head)
{
	printf("List: ");
	for (ListNode* p = head; p != NULL; p = p->link)
	{
		printf("%d->", p->data);
	}
	printf("\n");
}

int main(void)
{
	int menu;
	int num1, num2;

	ListNode* head = NULL;
	while (1)
	{
		printf("Menu\n");
		printf("(1) Insert\n");
		printf("(2) Delete\n");
		printf("(3) Print\n");
		printf("(0) Exit\n");
		printf("Enter the menu: ");
		scanf("%d", &menu);

		switch (menu)
		{
		case 0:
			printf("Exit the Program.\n");
			exit(1);
			break;
		case 1:
			printf("Enter the number and position: ");
			scanf("%d %d", &num1, &num2);
			if (head == NULL)
			{
				printf("List is empty. Insert at position 0..\n\n");
				head = insertFirst(head, num1);
				// 처음에는 움직이지 않고 입력이 가능하기에 0만을 출력합니다.
				printf("Move along the link: 0\n");
			}
			else if (num2 == 0) {
				head = insertFirst(head, num1);
				printf("Move along the link: 0\n");
			}
			else
			{
				ListNode* pre = head;
				ListNode* lastNode = NULL;
				int lastIndex = 0;

				while (pre != NULL && lastIndex < num2)
				{
					lastNode = pre;
					pre = pre->link;
					lastIndex++;
				}

				if (num2 >= lastIndex)
				{
					printf("The last index is %d. Insert at the end of the list.\n\n", lastIndex);
					head = insert(head, lastNode, num1);
					printf("Move along the link: %d\n", lastIndex);
				}
			}
			break;
		case 2:
			if (head == NULL)
			{
				printf("List is empty.\n");
				break;
			}						
			ListNode* pre = head;
			ListNode* lastNode = NULL;
			int lastIndex = 0;

			printf("Enter the position to delete: ");
			scanf("%d", &num1);
			if (num1 == 0) {
				head = deleteFirst(head, num1);
				printf("\nMove along the link: 0\n");
			}
			else {
				while (pre!=NULL && lastIndex < num1)
				{
					lastNode = pre;
					pre = pre->link;
					lastIndex++;
				}
				head = delete(head, lastNode);
				printf("\nMove along the link: %d\n" , lastIndex);
			}
			break;
		case 3:
			printList(head);
			break;
		default:
			printf("Invalid Menu. Please select again..\n");
			break;
		}
		printf("\n");
	}
}