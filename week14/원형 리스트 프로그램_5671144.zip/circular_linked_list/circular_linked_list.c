﻿#include <stdio.h>
#include <stdlib.h>

typedef int element;

typedef struct
{
	element data;
	struct ListNode* link;
}ListNode;

ListNode* insertFirst(ListNode* head, element data)
{
	ListNode* node = (ListNode*)malloc(sizeof(ListNode));
	node->data = data;
	if (head == NULL) {
		head = node;
		node->link = head;
	}
	else {
		node->link = head->link;
		head->link = node;
	}
	return head;
}

ListNode* insertLast(ListNode* head, element data)
{
	ListNode* node = (ListNode*)malloc(sizeof(ListNode));
	node->data = data;
	if (head == NULL) {
		head = node;
		node->link = head;
	}
	else {
		node->link = head->link;
		head->link = node;
		head = node;
	}
	return head;
}

void printList(ListNode* head) {
	ListNode* p;

	if (head == NULL) return;

	p = head->link;
	if (head->link == head) {
		printf("%d->\n", p->data);
		return;
	}
	do {
		printf("%d->", p->data);
		p = p->link;
	} while (p != head);

	printf("%d->", p->data);
	printf("\n");
}

ListNode* deleteFirst(ListNode* head) {
	if (head == NULL) {
		printf("리스트가 비어있습니다.\n");
		return head;
	}

	if (head->link == head) {
		head->link = NULL;
		return head;
	}
	else {
		ListNode* removed = head->link;
		ListNode* newFrist = removed->link;
		free(removed);
		head->link = newFrist;
		return head;
	}
}

ListNode* deleteLast(ListNode* head) {
	if (head == NULL) {
		printf("리스트가 비어있습니다.\n");
		return head;
	}

	if (head->link == head) {
		head->link = NULL;
		return head;
	}
	else {
		// 원형 리스트이기 에 삭제되는 노드는 head 보고,
		// head를 삭제하기위해 head 의 이전 노드를 찾습니다.
		ListNode* removePrevNode = head->link;
		while (1)
		{
			if (removePrevNode->link == head) {
				break;
			}
			else {
				removePrevNode = removePrevNode->link;
			}
		}
		if (head->link == removePrevNode) {
			removePrevNode->link = removePrevNode;
			return removePrevNode;
		}
		else {
			removePrevNode->link = head->link;
			return removePrevNode;
		}
	}
}

int main() {
	ListNode* head = NULL;
	

	int seletedMenu;
	int inputNum;
	while (1)
	{
		printf("***** Menu *****\n");
		printf("(1) Insert Frist\n");
		printf("(2) Insert Last\n");
		printf("(3) Delte Frist\n");
		printf("(4) Delte Last\n");
		printf("(5) Print List\n");
		printf("(0) Exit\n");
		printf("Enter the menu: ");
		scanf("%d", &seletedMenu);
		switch (seletedMenu)
		{
		case 0:
			printf("Exit the program.\n");
			exit(0);
			break;
		case 1:
			printf("Input a number: ");
			scanf("%d", &inputNum);
			head = insertFirst(head, inputNum);
			break;
		case 2:
			printf("Input a number: ");
			scanf("%d", &inputNum);
			head = insertLast(head, inputNum);
			break;
		case 3:
			head = deleteFirst(head);
			printf("First node has been deleted.\n");
			break;
		case 4:
			head = deleteLast(head);
			printf("Last node has been deleted.\n");
			break;
		case 5:
			printList(head);
			break;
		default:
			break;
		}
		printf("\n");
	}
}