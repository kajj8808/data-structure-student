﻿#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#define MAX_QUEUE_SIZE 20

typedef char element; // char element 즉 이번 덱 에서는 회문 을 검사하기 위해 문자를 사용하게 됩니다.

typedef struct
{
	element data[MAX_QUEUE_SIZE];
	int front;
	int rear;
} DequeType; // 덱 을 구현하기위해 data를 넣어놓을 수 있는 배열괴 front , rear 를 가진 구조체를 선언합니다.

// error 함수
void error(char *message)
{
	fprintf(stderr, "%s\n", message);
	return;
}

// init
void init(DequeType *queue)
{
	queue->front = 0;
	queue->rear = 0;
}

//
int isEmpty(DequeType *queue)
{
	return queue->front == queue->rear ? 1 : 0;
}

int isFull(DequeType *queue)
{
	return (queue->rear + 1) % MAX_QUEUE_SIZE == queue->front ? 1 : 0;
}

void printDeque(DequeType *queue)
{
	printf("DEQUE( front = %d rear = %d ) =", queue->front, queue->rear);
	if (!isEmpty(queue))
	{
		int index = queue->front;
		do
		{
			index = (index + 1) % MAX_QUEUE_SIZE;
			printf(" %d |", queue->data[index]);
			if (index == queue->rear)
			{
				break;
			}
		} while (index != queue->front);
		printf("\n");
	}
}
void addRear(DequeType *queue, element item)
{
	if (isFull(queue))
	{
		error("queue is Full");
		return;
	}
	queue->rear = (queue->rear + 1) % MAX_QUEUE_SIZE;
	queue->data[queue->rear] = item;
}

element getFront(DequeType *queue)
{
	if (isEmpty(queue))
	{
		error("queue is Empty");
		return -1;
	}
	return queue->data[(queue->front + 1) % MAX_QUEUE_SIZE];
}

void addFront(DequeType *queue, element item)
{
	if (isFull(queue))
	{
		error("queue is Full");
		return;
	}
	queue->data[queue->front] = item;
	queue->front = (queue->front - 1 + MAX_QUEUE_SIZE) % MAX_QUEUE_SIZE;
}

element deleteRear(DequeType *queue)
{
	int prev = queue->rear;
	if (isEmpty(queue))
	{
		error("queue is Empty");
		return -1;
	}
	queue->rear = (queue->rear - 1 + MAX_QUEUE_SIZE) % MAX_QUEUE_SIZE;
	return queue->data[prev];
}

// 삭제 함수
element deleteFront(DequeType *queue)
{
	if (isEmpty(queue))
	{
		error("queue is Empty");
		return -1;
	};
	queue->front = (queue->front + 1) % MAX_QUEUE_SIZE;
	return queue->data[queue->front];
}

element getRear(DequeType *queue)
{
	if (isEmpty(queue))
	{
		error("queue is Empty");
		return -1;
	}
	return queue->data[queue->rear];
}

int isPalindrome(char inputString[])
{
	DequeType queue;
	int len;
	char c;

	len = strlen(inputString);

	init(&queue);

	for (int i = 0; i < len; i++)
	{
		c = tolower(inputString[i]);
		if (isalpha(c))
		{
			addRear(&queue, c);
		}
	}

	for (int i = 0; i < queue.rear / 2; i++)
	{
		if (deleteFront(&queue) != deleteRear(&queue))
		{
			return 0;
		}
	}
	return 1;
}

int main()
{

	char input_string[100]; // 문자열을 입력받습니다.
	char yesNo[10];			// 프로그램을 다시시작 할지를 묻는 String 을 저장하기위해 사용합니다.

	while (1)
	{
		printf("Enter a string ( or input 'exit' ): ");
		fgets(input_string, sizeof(input_string), stdin);

		if (strcmp(input_string, "exit\n") == 0)
		{
			printf("Program exit\n");
			break;
		}

		input_string[strcspn(input_string, "\n")] = '\0'; // 개행 문자 제거
		if (isPalindrome(input_string) == 1)
		{
			printf("%s is a palindrome.\n", input_string);
		}
		else
		{
			printf("%s is not a palindrome.\n", input_string);
		}
		printf("\n");
	}

	return;
}