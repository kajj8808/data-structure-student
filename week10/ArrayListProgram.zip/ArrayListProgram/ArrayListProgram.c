﻿#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#define MAX_LIST_SIZE 100 // list 의 최대크기

typedef int element;

// array list 구조체
typedef struct
{
	element array[MAX_LIST_SIZE];
	int size; // length
} ArrayListType;

void error(char* message)
{
	fprintf(stderr, "%s\n", message);
	return;
}

// create
// init -> list 를 주고 list 를 초기화
void init(ArrayListType* list)
{
	list->size = 0;
}

bool isEmpty(ArrayListType* list)
{
	return list->size == 0 ? true : false;
}

bool isFull(ArrayListType* list)
{
	return list->size == MAX_LIST_SIZE ? true : false;
}

element getEntry(ArrayListType* list, int pos)
{
	if (pos < 0 || pos >= list->size)
	{
		error("position error");
		return -1;
	}
	return list->array[pos];
}

void printList(ArrayListType* list)
{
	for (int i = 0; i < list->size; i++)
	{
		printf("%d->", list->array[i]);
	}
	printf("\n");
}

void insertLast(ArrayListType* list, element item)
{
	if (list->size >= MAX_LIST_SIZE)
	{
		error("list overflow");
		return;
	}
	list->size++;
	list->array[list->size] = item;
}

void insert(ArrayListType* list, int pos, element item)
{
	// full 이거나 postion 이 0 보다 작거나 , list 의 최대 사이즈보다 클때 에러처리
	if (isFull(list) || pos < 0 || pos > list->size)
	{
		error("insert error");
		return;
	}
	int moveCount = 0;
	// ex) size = 3 이면 0 1 2의 2 를 가르키게 합니다.
	for (int i = (list->size - 1); i >= pos; i--)
	{
		list->array[i + 1] = list->array[i];
		moveCount++;
	}
	printf("Move : %d\n", moveCount);
	list->array[pos] = item;
	list->size++;
}

element delete(ArrayListType* list, int pos)
{
	element item;
	if (isEmpty(list) || pos < 0 || pos >= list->size)
	{
		error("delete error");
		return -1;
	}
	// 값을 return 하기위해 복사해둡니다.
	item = list->array[pos];
	// 덮어 씌워 값을 삭제시켜줍니다.
	int moveCount = 0;
	for (int i = pos; i < (list->size - 1); i++)
	{
		list->array[i] = list->array[i + 1];
		moveCount++;
	}
	printf("Move : %d\n", moveCount);
	list->size--;
	return item;
}

int main()
{

	ArrayListType list;
	int menu;
	int num1, num2;

	init(&list);
	while (1)
	{

		printf("Menu\n");
		printf("(1) Insert\n");
		printf("(2) Delete\n");
		printf("(3) Print\n");
		printf("(0) Exit\n");
		printf("Enter the menu: ");
		scanf("%d", &menu);

		switch (menu)
		{
		case 0:
			printf("Exit the Program.\n");
			exit(1);
			break;
		case 1:
			printf("Enter the number and position: ");
			scanf("%d %d", &num1, &num2); // 값을 두 개 입력받아서 변수 두 개에 저장
			if (list.size == 0 && num2 != 0)
			{
				printf("List size is zero. please enter again( number postion ): ");
				scanf("%d %d", &num1, &num2);
			}
			insert(&list, num2, num1);

			break;
		case 2:
			if (isEmpty(&list))
			{
				printf("List is Empty\n"); 
				break;
			}
			printf("Enter the Position: ");
			scanf("%d", &num2);
			int item = delete (&list, num2);
			printf("Delete : %d\n", item);
			break;
		case 3:
			printList(&list);
			break;
		default:
			printf("Invalid id Menu. Please select again..\n");
			break;
		}
		printf("\n");
	}
}