﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char* element;

typedef struct ListNode
{
	element data;
	struct ListNode* link;
} ListNode;

typedef struct
{
	element data[100];
	int length;
} DeletedList;

ListNode* insertFirst(ListNode* head, element item)
{
	ListNode* node = (ListNode*)malloc(sizeof(ListNode));
	node->data = item;
	node->link = head;
	head = node;
	return head;
}

ListNode* deleteFirst(ListNode* head)
{
	ListNode* removed;
	if (head == NULL)
	{
		return NULL;
	}
	removed = head;
	head = removed->link;
	free(removed);
	return head;
}

ListNode* insert(ListNode* head, ListNode* pre, element item)
{
	ListNode* node = (ListNode*)malloc(sizeof(ListNode));
	node->data = item;
	node->link = pre->link;
	pre->link = node;
	return head;
}

ListNode* deleteListNode(ListNode* head, ListNode* target, DeletedList* delList)
{
	ListNode* pre = NULL;
	ListNode* current = head;

	while (current != NULL && current != target)
	{
		pre = current;
		current = current->link;
	}

	if (pre == NULL)
	{
		head = current->link;
	}
	else
	{
		pre->link = current->link;
	}

	delList->data[delList->length] = current->data;
	delList->length++;

	free(current);
	return head;
}

ListNode* searchList(ListNode* head, element x)
{
	ListNode* node = head;
	while (node != NULL)
	{
		if (strcmp(node->data, x) == 0)
			return node;
		node = node->link;
	}
	return NULL;
}

ListNode* insertLast(ListNode* head, element item)
{
	ListNode* node = (ListNode*)malloc(sizeof(ListNode));
	node->data = item;
	node->link = NULL;

	if (head == NULL)
	{
		head = node;
	}
	else
	{
		ListNode* current = head;
		while (current->link != NULL)
		{
			current = current->link;
		}
		current->link = node;
	}
	return head;
}

void printList(ListNode* head)
{
	printf("\nFruit list: \n");
	for (ListNode* p = head; p != NULL; p = p->link)
	{
		printf("%s->", p->data);
	}
	printf("NULL\n");
}

int main(void)
{
	int menu;

	ListNode* head = NULL;
	DeletedList delList;
	delList.length = 0; // Initialize delList
	char input_string[30];
	char* fruitList[10] = {
		"Mango",
		"Orange",
		"Apple",
		"Grape",
		"Cherry",
		"Plum",
		"Guava",
		"Raspberry",
		"Banana",
		"Peach",
	};
	for (int i = 0; i < 10; i++)
	{
		head = insertLast(head, fruitList[i]);
	}

	while (1)
	{
		char* input_string = (char*)malloc(30);

		printf("==== Menu ====\n");
		printf("1. Input \n");
		printf("2. Delete\n");
		printf("3. Print \n");
		printf("4. Exit\n");
		printf("Select number: ");
		scanf("%d", &menu);
		printf("\n");
		switch (menu)
		{
		case 1:
			printf("Fruit name to add: ");
			scanf(" %[^\n]s", input_string);

			ListNode* insertNode = searchList(head, input_string);
			if (insertNode) {
				printf("%s already exists.\n", insertNode->data);
				printList(head);

			}
			else {
				head = insertLast(head, input_string);
				printf("%s has been added.\n", input_string);
				printList(head);
			}
			break;
		case 2:
			printf("Fruit name to delete: ");
			scanf("%s", input_string); // 표준 입력을 받아서 배열 형태의 문자열에 저장

			ListNode* deleteNode = searchList(head, input_string);

			if (deleteNode)
			{
				head = deleteListNode(head, deleteNode, &delList);
				printf("%s has been deleted.\n", delList.data[delList.length - 1]);
			}
			else
			{
				printf("%s is not on the list.\n", input_string);
			}
			printList(head);
			break;
		case 3:
			printf("List of the deleted fruits : ");

			if (delList.length == 0)
			{
				printf("NULL\n");
				printList(head);
				break;
			}

			for (int i = 0; i < delList.length; i++) {
				;
				printf("%s->", delList.data[i]);
			}
			printf("NULL");
			printf("\n");
			break;
		case 4:
			printf("Exit the program.\n");
			exit(0);
			break;
		default:
			break;
		}
		printf("\n");
	}
	return 0;
}